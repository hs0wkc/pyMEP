from setuptools import setup, find_packages

setup(
   name="pyMEP",
   version='0.2.0',
   author="L.Euttana",
   author_email='hs0wkc@hotmail.com',
   url="https://github.com/hs0wkc/pyMEP",
   description="Python Library for MEP Engineering.",
   long_description=open('README.md').read(),
   long_description_content_type='text/markdown',
   include_package_data=True,
   classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
   ],
   python_requires='>=3.8',
   packages = find_packages(),
   setup_requires=['setuptools-git-versioning'],
   install_requires=[
         'msvc_runtime',
         'numpy',
         'pandas',
         'matplotlib',
         'scipy',
         'pint',
         'PsychroLib',
         'coolprop',
         'iapws>=1.5.3',
         'pytz'
      ],
   version_config={
       "dirty_template": "{tag}",
   }
)